﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddPost : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            // DB 연결
            string connectionString = ConfigurationManager.ConnectionStrings["TrainBookingConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Connection 열기
                connection.Open();

                // 쿼리 작성 (ID 열은 명시하지 않음)
                string query = "INSERT INTO gesi (UserId, title, Contents, date, totalview) VALUES (@UserId, @title, @Contents, @date, @totalview)";

                // 파라미터 설정
                string UserId = txtUserId.Text;

                string title = txtTitle.Text;
                string Content = txtContent.Text;
                DateTime date = DateTime.Now;
                int totalview = 0;

                // 쿼리 실행
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", UserId);

                    command.Parameters.AddWithValue("@title", title);
                    command.Parameters.AddWithValue("@Contents", Content);
                    command.Parameters.AddWithValue("@date", date);
                    command.Parameters.AddWithValue("@totalview", totalview);

                    command.ExecuteNonQuery();
                }
            }

            // 등록이 됐을 때
            Response.Redirect("~/Board.aspx");
        }
        catch (Exception ex)
        {
            // 예외가 발생하면 에러 메시지를 출력합니다.
            Response.Write(ex.Message);
        }
    }

    protected void return_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Board.aspx");
    }

    protected void txtUserId_TextChanged(object sender, EventArgs e)
    {

    }

    protected void txtTitle_TextChanged(object sender, EventArgs e)
    {

    }

    protected void txtContent_TextChanged(object sender, EventArgs e)
    {

    }


}
