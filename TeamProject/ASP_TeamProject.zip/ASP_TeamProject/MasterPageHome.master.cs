﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPageHome : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("HomePage.aspx");
    }

    protected void Timer1_Tick1(object sender, EventArgs e)
    {
        Label1.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
    }


    protected void btnBookedInfo_Click(object sender, EventArgs e)
    {
        Response.Redirect("BookedInfo.aspx");
        // 로그인 안했을 때 팝업창으로 로그인하라고 띄우기
    }

    protected void btnRouteInfo_Click(object sender, EventArgs e)
    {
        Response.Redirect("RouteInfo.aspx");
    }

    protected void btnBoard_Click(object sender, EventArgs e)
    {
        Response.Redirect("Board.aspx");
        // 로그인 안했을 때 팝업창으로 로그인하라고 띄우기
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}
