﻿using System;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class ReadBoard : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // 쿼리 문자열에서 gesinumber 매개변수가 있는지 확인
            if (Request.QueryString["gesinumber"] != null)
            {
                int gesinumber;
                // gesinumber 매개변수를 정수로 변환 시도
                if (int.TryParse(Request.QueryString["gesinumber"], out gesinumber))
                {
                    BindContentToControls(gesinumber);


                   /*string currentUserId = GetCurrentUserId();.
                    bool isAuthorOrAdmin = CheckIfUserIsAuthorOrAdmin(currentUserId);
                    Button1.Visible = isAuthorOrAdmin;
                    Button2.Visible = isAuthorOrAdmin;*/




                }
                else
                {
                    // 잘못된 gesinumber 매개변수 처리
                    lblContents.Text = "잘못된 gesinumber 매개변수입니다.";
                }
            }
            else
            {
                // 누락된 gesinumber 매개변수 처리
                lblContents.Text = "gesinumber 매개변수가 누락되었습니다.";
            }
        }
    }


    private void BindContentToControls(int gesinumber)
    {
        string connectionString = "Data Source=DESKTOP-URTFPON\\MSSQLSERVER01;Initial Catalog=TrainBooking;User ID=sa2;Password=1234;";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string query = "SELECT UserId, title, contents, date FROM gesi WHERE gesinumber = @gesinumber";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@gesinumber", gesinumber);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        lblWriter.Text = reader["UserId"].ToString();
                        lbldate.Text = reader["date"].ToString();
                        lblTitle.Text = reader["title"].ToString();
                        lblContents.Text = reader["contents"].ToString();
                    }
                    else
                    {
                        lblContents.Text = "해당 게시물을 찾을 수 없습니다.";
                    }
                }
            }
        }
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("ChangeBoard.aspx?gesinumber=" + Request.QueryString["gesinumber"]);
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["gesinumber"] != null)
        {
            int gesinumber;
            if (int.TryParse(Request.QueryString["gesinumber"], out gesinumber))
            {
                if (DeleteContent(gesinumber))
                {
                    // 삭제 성공 시 Board.aspx 페이지로 이동
                    Response.Redirect("Board.aspx");
                }
                else
                {
                    // 삭제 실패 시 메시지 출력
                    lblContents.Text = "게시물 삭제에 실패했습니다.";
                }
            }
            else
            {
                // 잘못된 gesinumber 매개변수 처리
                lblContents.Text = "잘못된 gesinumber 매개변수입니다.";
            }
        }
        else
        {
            // 누락된 gesinumber 매개변수 처리
            lblContents.Text = "gesinumber 매개변수가 누락되었습니다.";
        }
    }

    private bool DeleteContent(int gesinumber)
    {
        string connectionString = "Data Source=DESKTOP-URTFPON\\MSSQLSERVER01;Initial Catalog=TrainBooking;User ID=sa2;Password=1234;";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string query = "DELETE FROM gesi WHERE gesinumber = @gesinumber";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@gesinumber", gesinumber);

                int rowsAffected = cmd.ExecuteNonQuery();

                return rowsAffected > 0; // 삭제된 행이 있으면 true 반환, 아니면 false 반환
            }
        }
    }


    protected void btnGoBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Board.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {

    }

    /*
    private string GetCurrentUserId()
    {
        // 로그인한 사용자의 ID를 가져온다.
        int userId = Membership.GetUserIdFromUsername(HttpContext.Current.User.Identity.Name);

        // 로그인하지 않은 경우 빈 문자열을 반환한다.
        if (userId == -1)
        {
            return string.Empty;
        }

        // 로그인한 사용자의 ID를 반환한다.
        return Membership.GetUserById(userId).UserId;
    }

    private bool CheckIfUserIsAuthorOrAdmin(string currentUserId)
    {
        // 현재 사용자가 글의 작성자인지 확인한다.
        if (currentUserId != null && currentUserId != string.Empty && currentUserId == lblWriter.Text)
        {
            return true;
        }

        // 현재 사용자가 어드민인지 확인한다.
        string adminId = "admin";
        if (currentUserId != null && currentUserId != string.Empty && adminId == currentUserId)
        {
            return true;
        }

        // 현재 사용자가 글의 작성자도 아니고 어드민도 아니다.
        return false;
    }
    */

}


