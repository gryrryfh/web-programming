﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Board : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void gvList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ViewDetails" && e.CommandArgument != null)
        {
            Response.Redirect("ReadBoard.aspx?gesinumber=" + e.CommandArgument.ToString());

        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddPost.aspx");
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}