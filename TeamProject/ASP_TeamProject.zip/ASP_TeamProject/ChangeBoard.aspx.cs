﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

public partial class ChangeBoard : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["gesinumber"] != null)
            {
                int gesinumber;
                if (int.TryParse(Request.QueryString["gesinumber"], out gesinumber))
                {
                    BindContentToControls(gesinumber);
                }
                else
                {
                    Response.Write("잘못된 gesinumber 매개변수입니다.");
                }
            }
            else
            {
                Response.Write("gesinumber 매개변수가 누락되었습니다.");
            }
        }
    }

    private void BindContentToControls(int gesinumber)
    {
        string connectionString = "Data Source=DESKTOP-URTFPON\\MSSQLSERVER01;Initial Catalog=TrainBooking;User ID=sa2;Password=1234;";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string query = "SELECT UserId, title, contents, date FROM gesi WHERE gesinumber = @gesinumber";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@gesinumber", gesinumber);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        lblWriter.Text = reader["UserId"].ToString();
                        lbldate.Text = reader["date"].ToString();
                        txtTitle.Text = reader["title"].ToString();
                        txtContents.Text = reader["contents"].ToString();
                    }
                    else
                    {
                        Response.Write("해당 게시물을 찾을 수 없습니다.");
                    }
                }
            }
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        UpdateBoard();
    }

    protected void btnGoBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReadBoard.aspx?gesinumber=" + Request.QueryString["gesinumber"]);
    }

    private void UpdateBoard()
    {
        int gesinumber;
        if (int.TryParse(Request.QueryString["gesinumber"], out gesinumber))
        {
            string connectionString = "Data Source=DESKTOP-URTFPON\\MSSQLSERVER01;Initial Catalog=TrainBooking;User ID=sa2;Password=1234;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "UPDATE gesi SET title = @title, contents = @contents WHERE gesinumber = @gesinumber";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@title", txtTitle.Text);
                    cmd.Parameters.AddWithValue("@contents", txtContents.Text);
                    cmd.Parameters.AddWithValue("@gesinumber", gesinumber);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        lblUpdateResult.Text = "게시물이 성공적으로 수정되었습니다.";
                    }
                    else
                    {
                        lblUpdateResult.Text = "게시물 수정에 실패했습니다.";
                    }
                }
            }
        }
        else
        {
            lblUpdateResult.Text = "잘못된 gesinumber 매개변수입니다.";
        }
    }
}
