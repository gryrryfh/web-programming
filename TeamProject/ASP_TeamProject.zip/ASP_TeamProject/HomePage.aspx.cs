﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HomePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage.Text = User.Identity.Name + "님 반갑습니다.";
    }

    protected void GoSelectSeats_Click(object sender, EventArgs e)
    {
        Response.Redirect("Payment.aspx");
    }

    protected void btn_Logout_Click(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
    }
}