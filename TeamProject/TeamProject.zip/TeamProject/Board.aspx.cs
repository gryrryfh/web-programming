﻿using System;
using System.Web.UI.WebControls;

public partial class Board : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void gvList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Details")
        {
            int index = Convert.ToInt32(e.CommandArgument);
            string gesinumber = gvList.DataKeys[index].Value.ToString();

            // 여기에서 선택된 게시물의 contents를 가져와서 새로운 페이지로 전달하거나
            // 직접 처리하는 로직을 추가할 수 있습니다.
            string contents = GetContentsFromDatabase(gesinumber);

            // 예제: 다른 페이지로 이동하면서 contents 전달
            string url = "ReadBoard.aspx?gesinumber=" + gesinumber + "&contents=" + contents;
            Response.Redirect(url);
        }
    }

    private string GetContentsFromDatabase(string gesinumber)
    {
        // 데이터베이스에서 해당 gesinumber에 대한 contents를 가져오는 로직을 추가하세요.
        // 필요에 따라 SqlDataSource를 사용하거나 직접 코드를 작성하여 데이터를 조회합니다.
        // 아래는 간단한 예제로 가정한 코드입니다.
        string contents = "컨텐츠 내용 가져오기";

        return contents;
    }

    protected void btnAddPost_Click(object sender, EventArgs e)
    {
        // 글 등록 버튼 클릭 시 필요한 동작을 수행할 수 있습니다.
        // 예: 글 등록 페이지로 이동
        Response.Redirect("AddPost.aspx");
    }
}
