﻿using System;
using System.Web.UI.WebControls;

public partial class ReadBoard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // QueryString에서 gesinumber와 contents 가져오기
            string gesinumber = Request.QueryString["gesinumber"];
            string contents = Request.QueryString["contents"];

            // 여기에서 필요한 데이터베이스 조회 로직을 추가할 수 있습니다.
            // 예제로 간단한 값을 사용합니다.
            string title = GetTitleFromDatabase(gesinumber);

            // 가져온 데이터를 페이지의 컨트롤에 설정
            lblTitle.Text = "글 제목: " + title;
            txtTitle.Text = title;
            txtContent.Text = contents;
        }
    }

    private string GetTitleFromDatabase(string gesinumber)
    {
        // 데이터베이스에서 해당 gesinumber에 대한 title을 가져오는 로직을 추가하세요.
        // 아래는 간단한 예제로 가정한 코드입니다.
        return "게시물 제목";
    }

    protected void btnGoBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Board.aspx");
    }
}
