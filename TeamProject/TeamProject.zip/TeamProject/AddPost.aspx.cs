﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddPost : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["TrainBookingConnectionString"].ConnectionString;

        // 새로운 글을 추가하기 위한 SQL 쿼리
        string insertQuery = "INSERT INTO YourTableName (Title, Contents, Date) VALUES (@Title, @Contents, GETDATE())";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
            {
                // 파라미터 추가
                cmd.Parameters.AddWithValue("@Title", txtTitle.Text);
                cmd.Parameters.AddWithValue("@Contents", txtContent.Text);

                // 데이터베이스 연결 열기
                connection.Open();

                // 쿼리 실행
                cmd.ExecuteNonQuery();
            }
        }

    }

    protected void return_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Board.aspx");
    }

    protected void txtTitle_TextChanged(object sender, EventArgs e)
    {

    }

    protected void txtContent_TextChanged(object sender, EventArgs e)
    {

    }
}