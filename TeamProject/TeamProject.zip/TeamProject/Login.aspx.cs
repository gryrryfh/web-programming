﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.IO;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button8_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection sc = new SqlConnection(WebConfigurationManager.ConnectionStrings["Train"].ConnectionString);
            SqlCommand cmd = new SqlCommand();

            string UserID = txtUserName.Text;
            string UserPa = txtPa.Text;

            cmd.Connection = sc;

            cmd.CommandText = "SELECT * FROM Membership WHERE ID='" + UserID + "' AND Password='" + UserPa + "'";

            sc.Open();

            SqlDataReader rs = cmd.ExecuteReader();

            if (rs.HasRows == true)
            {
                Response.Write(@"<script>alert('로그인 성공');</script>");
                FormsAuthentication.SetAuthCookie(UserID, false);
                Response.Redirect("~/HomePage.aspx");
            }
            else
            {
                Response.Write(@"<script>alert('로그인 실패');</script>");
            }

            sc.Close();
        }
        catch (Exception ex)
        {
            Response.Write(@"<script>alert('오류 발생: " + ex.Message + "');</script>");
        }
    }

    protected void Button9_Click(object sender, EventArgs e)
    {
        try
        {
            string m_name = txtName.Text;
            string m_id = txtID.Text;
            string m_pa = txtPassword.Text;
            string m_repa = txtRetype.Text;
            string m_email = txtEMail.Text;

            if (m_pa != m_repa)
            {
                Response.Write(@"<script>alert('비밀번호와 비밀번호 확인이 일치하지 않습니다.');</script>");
            }
            else if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtID.Text) || string.IsNullOrWhiteSpace(txtPassword.Text) || string.IsNullOrWhiteSpace(txtEMail.Text))
            {
                Response.Write(@"<script>alert('빈 칸이 있습니다.');</script>");
            }

            else
            {
                SqlConnection sc = new SqlConnection(WebConfigurationManager.ConnectionStrings["Train"].ConnectionString);

                SqlCommand scmd = new SqlCommand("InsertMember", sc);

                scmd.CommandType = CommandType.StoredProcedure;

                SqlParameter spIdx = new SqlParameter("@IDX", SqlDbType.Int);
                spIdx.Direction = ParameterDirection.Output;

                SqlParameter sql_mname = new SqlParameter("@name", SqlDbType.VarChar, 250);
                sql_mname.Value = m_name;

                SqlParameter sql_mid = new SqlParameter("@ID", SqlDbType.VarChar, 50);
                sql_mid.Value = m_id;

                SqlParameter sql_mpa = new SqlParameter("@Password", SqlDbType.VarChar, 50);
                sql_mpa.Value = m_pa;

                SqlParameter slq_memail = new SqlParameter("@Email", SqlDbType.VarChar, 50);
                slq_memail.Value = m_email;

                scmd.Parameters.Add(spIdx);
                scmd.Parameters.Add(sql_mname);
                scmd.Parameters.Add(sql_mid);
                scmd.Parameters.Add(sql_mpa);
                scmd.Parameters.Add(slq_memail);

                sc.Open();

                scmd.ExecuteNonQuery();

                sc.Close();

                int newIdx = (int)spIdx.Value;

                Response.Write("새로운 IDX는 " + newIdx.ToString() + "입니다");

                sc.Dispose();
                scmd.Dispose();
                Response.Write(@"<script>alert('회원가입 완료.');</script>");
                Response.Redirect(Request.ServerVariables["SCRIPT_NAME"]);
            }
        }
        catch (Exception ex)
        {
            Response.Write(@"<script>alert('오류 발생: " + ex.Message + "');</script>");
        }
    }
}
